# WahyuCoin

Build Instructions (Termux/Linux):
1. Install dependencies
2. Run `./autogen.sh && ./configure && make`
3. Start node with `./wahyucoind`

Premine: 5 juta WAHYU
Total Supply: 10 juta
Block Time: 2 menit
Algoritma: Scrypt
